﻿//한줄 삭제: ctrl + L


#include "pch.h"
#include <iostream>
#include <stdio.h>

using namespace std;

int main(void)
{
    cout << "Hello World!\n"; 
	int num1, num2;

	cin >> num1 >> num2;
	cout << num1 << " " << num2;
}

