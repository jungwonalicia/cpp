﻿#include "pch.h"
#include <iostream>
using namespace std;

//설명(주석) 
//실행=> 컨트롤 + f5
//복사=> 컨트롤 + d

int main()
{
    cout << "Hello World!\n"; 
	cout << "안녕하세요..\n";
	cout << "홍길동입니다..\n";
	cout << "C++프로그래밍입니다.." << endl;
}
